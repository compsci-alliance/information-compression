# Image SVD
# 2017 November Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy
from matplotlib import pyplot


img = Image.open("./sample.jpg") ## load image
img_gray = img.convert("L") ## convert to grayscale
#img_gray.show() ## show image
img_gray.save("./gray.png") ## save grayscale image
#img_gray.save("./gray.jpg") ## save grayscale image in jpg

array = np.array(img_gray) ## convert to ndarray

u,s,vt = np.linalg.svd(array,full_matrices=False) ## svd 

## normalization
s = s/np.sqrt(np.sum(s**2))

output_sv = len(s) ## number of singular values to output
pyplot.title("Singular Value Spectrum of the image")
pyplot.plot(np.arange(output_sv),s[:output_sv],"o")
pyplot.xlabel("Index")
pyplot.ylabel("sigma")
pyplot.yscale("log")
pyplot.show()


