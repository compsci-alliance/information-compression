# Tensor Renormalization Groupe
# based on M. Levin and C. P. Nave, PRL 99 120601 (2007)
# and X.-C. Gu, M. Levin, and X.-G. Wen, PRB 78, 205116(2008).
# 2018 Jan. Tsuyoshi Okubo

# coding:utf-8
import numpy as np
import scipy as scipy
import scipy.linalg as linalg
import argparse
import TRG 
from matplotlib import pyplot

#input from command line
def parse_args():
    parser = argparse.ArgumentParser(description='Tensor Network Renormalization for Square lattice Ising model')
    parser.add_argument('-D', metavar='D',dest='D', type=int, default=8,
                        help='set bond dimension D for TRG')
    parser.add_argument('-n', metavar='n',dest='n', type=int, default=4,
                        help='set size n representing L=2^n')
    parser.add_argument('-T', metavar='T',dest='T', type=float, default=2.0,
                        help='set Temperature')
    parser.add_argument('--energy', action='store_const', const=True,
                        default=False, help='Calculate energy density by using impurity tensor')
    
    return parser.parse_args()

def Calculate_TRG(D=8,n=4,T=2.0):

    TRG_step = 2*n - 1
    L = 2**n
    
    ## single calculation
    free_energy_density,s1,s2 = TRG.TRG_Square_Ising(T,D,TRG_step,Energy_flag=False)
    print "T= ", T
    print "L= ", L
    print "D= ", D
    print "free energy density= ",free_energy_density
    
    output_sv = len(s1) ## number of singular values to output
    pyplot.title("Singular Value Spectrum of TRG with T= "+repr(T)+", D= "+repr(D) + " at "+repr(TRG_step)+" TRG steps")
    pyplot.plot(np.arange(output_sv),s1[:output_sv],"o")
    pyplot.xlabel("Index")
    pyplot.ylabel("sigma")
    pyplot.yscale("log")
    pyplot.show()

    
def main():
    ## read params from command line
    args = parse_args()
    Calculate_TRG(args.D,args.n,args.T)    
    
if __name__ == "__main__":
    main()

