# Image compression by HOSVD
# for color image
# 2017 October Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy


img = Image.open("./sample_color.jpg") ## load image
img.show() ## show image
img.save("./img_original.png") ## save image

array = np.array(img) ## convert to ndarray
#print "Array shape:", array.shape

array_truncated = np.zeros(array.shape)

## hosvd for tensor

chi = 200

## row
matrix = np.reshape(array,(array.shape[0],array.shape[1]*array.shape[2]))
u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 
    
#truncation
u1 = u[:,:chi]

## column
matrix = np.reshape(np.transpose(array,(1,0,2)),(array.shape[1],array.shape[0]*array.shape[2]))
u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 
    
#truncation
u2 = u[:,:chi]

## for RGB we do not truncate 
## make projectors
p1 = np.dot(u1,(u1.conj()).T)
p2 = np.dot(u2,(u2.conj()).T)

## make truncated array
array_truncated = np.tensordot(np.tensordot(array,p1,axes=(0,1)),p2,axes=(0,1)).transpose(1,2,0)
    

img_truncated = Image.fromarray(np.uint8(array_truncated)) ## convert to RGB
img_truncated.show() ## show image
img_truncated.save("./img_truncated.png") ## save compressed image
#img_truncated.save("./img_truncated.jpg") ## save compressed image in jpg
