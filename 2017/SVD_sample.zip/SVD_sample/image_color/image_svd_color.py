# Image compression by SVD
# for color image
# 2017 October Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy


img = Image.open("./sample_color.jpg") ## load image
img.show() ## show image
img.save("./img_original.png") ## save image

array = np.array(img) ## convert to ndarray
print "Array shape:", array.shape

array_truncated = np.zeros(array.shape)

## svd for each color

chi = 100
for i in range(3):
    u,s,vt = np.linalg.svd(array[:,:,i],full_matrices=False) ## svd 
    
    #truncation
    u = u[:,:chi]
    vt = vt[:chi,:]
    s = s[:chi]

    array_truncated[:,:,i] = np.dot(np.dot(u,np.diag(s)),vt) ## make truncated array
    


img_truncated = Image.fromarray(np.uint8(array_truncated)) ## convert to RGB
img_truncated.show() ## show image
img_truncated.save("./img_truncated.png") ## save compressed image
#img_truncated.save("./img_truncated.jpg") ## save compressed image in jpg
