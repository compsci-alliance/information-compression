# Image compression by SVD
# 2017 October Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy


img = Image.open("./sample.jpg") ## load image
img_gray = img.convert("L") ## convert to grayscale
img_gray.show() ## show image
img_gray.save("./gray.png") ## save grayscale image
#img_gray.save("./gray.jpg") ## save grayscale image in jpg


array = np.array(img_gray) ## convert to ndarray

u,s,vt = np.linalg.svd(array,full_matrices=False) ## svd 

#truncation
chi = 100
u = u[:,:chi]
vt = vt[:chi,:]
s = s[:chi]

array_truncated = np.dot(np.dot(u,np.diag(s)),vt) ## make truncated array

img_gray_truncated = Image.fromarray(np.uint8(array_truncated)) ## convert to grayscale image

img_gray_truncated.show() ## show image
img_gray_truncated.save("./gray_truncated.png") ## save compressed image
#img_gray_truncated.save("./gray_truncated.jpg") ## save compressed image in jpg

