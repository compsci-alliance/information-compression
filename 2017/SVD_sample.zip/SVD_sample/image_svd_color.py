# Image compression by SVD
# for color image
# 2017 Octorbar Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy


img = Image.open("./sample.jpg") ## load image
img.show() ## show image
img.save("./gray.png") ## save grayscale image
