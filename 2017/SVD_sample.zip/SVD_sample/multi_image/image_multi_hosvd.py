# Image compression by HOSVD
# for multi grayscale images
# 2017 October Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy

array=[]
for i in range(1,11):
    img = Image.open("./samples/"+repr(i)+".bmp") ## load image    
    array.append(np.array(img)) ## convert to ndarray
array=np.array(array).transpose(1,2,0)

array_truncated = np.zeros(array.shape)

chi = 30
chi_p = 9

## row
matrix = np.reshape(array,(array.shape[0],array.shape[1]*array.shape[2]))
u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 
    
#truncation
u1 = u[:,:chi]

## column
matrix = np.reshape(np.transpose(array,(1,0,2)),(array.shape[1],array.shape[0]*array.shape[2]))
u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 
    
#truncation
u2 = u[:,:chi]

## layer
matrix = np.reshape(np.transpose(array,(2,0,1)),(array.shape[2],array.shape[0]*array.shape[1]))
u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 
    
#truncation
u3 = u[:,:chi_p]

## make projectors
p1 = np.dot(u1,(u1.conj()).T)
p2 = np.dot(u2,(u2.conj()).T)
p3 = np.dot(u3,(u3.conj()).T)

## make truncated array
array_truncated = np.tensordot(np.tensordot(np.tensordot(array,p1,axes=(0,1)),p2,axes=(0,1)),p3,axes=(0,1))
    
for i in range(1,11):    
    img_truncated = Image.fromarray(np.uint8(array_truncated[:,:,i-1])) ## convert to each image
    img_truncated.save("./outputs/"+repr(i)+".bmp") ## save compressed image




