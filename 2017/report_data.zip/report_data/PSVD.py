import sys
import numpy as np
from numpy.random import *

# definition of a prediction function
# U and O are feature vector
def p_UT_O(UT,O):
	if UT.shape[1]==O.shape[0]:
		q = np.dot(UT,O)
		i,j=np.where(q < 0.0)
		for k in range(len(i)):
			q[i[k]][j[k]] = 0.0
		i,j=np.where(q > 4.0)
		for k in range(len(i)):
			q[i[k]][j[k]] = 4.0
		q = q + 1.0
		return q	
	else:
		print("Shape of inputed matrices is not appropriate!")

argvs = sys.argv
argc = len(argvs)
inputfile = open(argvs[1], "r")
f = int(argvs[2]) # rank
imax = int(argvs[3]) # maximum iteration

# read an ranting matrix
line = inputfile.readline()
data = line.split()
L = int(data[0])
M = int(data[1])
V = np.zeros((L,M))
I = np.zeros((L,M))
line = inputfile.readline()
while line:
	data = line.split()
	ell = int(data[0])	
	m   = int(data[1])
	V[ell][m] = float(data[2])
	I[ell][m] = 1.0
	line = inputfile.readline()

# making an initial guess for U and O
sumV = np.sum(V)
sumI = np.sum(I)
avrsum = sumV/float(sumI)
r = np.sqrt((avrsum-1.0)/float(f)) 
UT = 0.1*2*r*(rand(L,f)-0.5) + r # initialize UT
O  = 0.1*2*r*(rand(f,M)-0.5) + r # initialize O

# hyper parameters
ku = 0.1
ko = 0.1

# parameter for steepest descent
mu = 0.1

for i in range(imax):
	# cost function
	E =  0.5*np.sum(I*((V - p_UT_O(UT,O))*(V - p_UT_O(UT,O))))
	E += 0.5*ku*(np.sum(UT*UT))
	E += 0.5*ko*(np.sum(O*O))
	
	# construction of gradient
	gradUT =  np.dot(I*(V-p_UT_O(UT,O)),O.T)
	gradUT -= ku*UT
	gradO  =  np.dot(UT.T,I*(V-p_UT_O(UT,O)))
	gradO  -= ko*O

	# updating UT and O
	UT += mu*gradUT
	O  += mu*gradO

	# root mean square error
	RMSE = np.sum(I*(V-p_UT_O(UT,O))*(V-p_UT_O(UT,O)))
	
	print i,E,RMSE

# output is stored in *.out
str0 = argvs[1].split('.')
print str0[0],str0[1]
f = open(str0[0]+'.out','w')
f.write('%d %d\n' % (L,M))
for m in range(M):
	for ell in range(L):
		f.write('%d %d %f\n' % (ell,m,p_UT_O(UT,O)[ell][m]))
f.close()
print p_UT_O(UT,O)
