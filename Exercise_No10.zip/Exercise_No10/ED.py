# Exact diagonalization for spin chain
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import scipy.linalg as linalg
import scipy.sparse as spr
import scipy.sparse.linalg as spr_linalg
import argparse

def set_Hamiltonian_S(m,Delta,hx,D,N,periodic=False):
    ## N site chain, open boundary
    ## m = 2S+1
    ## Delta: for XXZ
    ## hx: external field along x direction
    ## D: single ion anisotropy
    
    Sp = np.zeros((m,m))
    for i in range(1,m):
        Sp[i-1,i] = np.sqrt(i * (m - i))

    Sp = spr.csr_matrix(Sp)

    Sm = np.zeros((m,m))
    for i in range(0,m-1):
        Sm[i+1,i] = np.sqrt((i + 1.0) * (m - 1.0 - i))

    Sm = spr.csr_matrix(Sm)

    Sz = np.zeros((m,m))
    for i in range(m):
        Sz[i,i] = 0.5 * (m - 1.0) - i
        
    Sz = spr.csr_matrix(Sz)

    Id = spr.identity(m,format="csr")

    
    Sx = 0.5 * (Sp + Sm)
    Sz2 = spr.csr_matrix.dot(Sz,Sz)

    Ham = spr.csr_matrix((m**N,m**N))

    for i in range(N):
        if (i==0):
            mx = Sx
            z2 = Sz2
        else:
            mx = Id
            z2 = Id
        for j in range(1,N):
            if (j==i) :
                mx = spr.kron(mx,Sx)
                z2 = spr.kron(z2,Sz2)
            else:
                mx = spr.kron(mx,Id)
                z2 = spr.kron(z2,Id)


        Ham -= hx * mx
        Ham += D * z2
    for i in range(N-1):
        if (i==0):
            zz = Sz
            pm = Sp
            mp = Sm
        else:
            zz = Id
            pm = Id
            mp = Id
            
        for j in range(1,N):
            if (j==i):
                zz = spr.kron(zz,Sz)
                pm = spr.kron(pm,Sp)
                mp = spr.kron(mp,Sm)
            elif j==i+1:
                zz = spr.kron(zz,Sz)
                pm = spr.kron(pm,Sm)
                mp = spr.kron(mp,Sp)
            else:
                zz = spr.kron(zz,Id)
                pm = spr.kron(pm,Id)
                mp = spr.kron(mp,Id)
        Ham += Delta * zz
        Ham += 0.5 * pm
        Ham += 0.5 * mp
    if periodic:
        zz = Sz
        pm = Sm
        mp = Sp
            
        for j in range(1,N-1):
            zz = spr.kron(zz,Id)
            pm = spr.kron(pm,Id)
            mp = spr.kron(mp,Id)
        zz = spr.kron(zz,Sz)
        pm = spr.kron(pm,Sp)
        mp = spr.kron(mp,Sm)

        Ham += Delta * zz
        Ham += 0.5 * pm
        Ham += 0.5 * mp
        
    return Ham

def Calc_GS(m,Delta,hx,D,N,k=5,periodic=False):
    Ham = set_Hamiltonian_S(m,Delta,hx,D,N,periodic)    
    eig_val,eig_vec = spr_linalg.eigsh(Ham,k=k,which="SA")
    return eig_val,eig_vec


#input from command line
def parse_args():
    parser = argparse.ArgumentParser(description='ED siumulator for one dimensional spin model')
    parser.add_argument('-N', metavar='N',dest='N', type=int, default=10,
                        help='set system size N')
    parser.add_argument('-Delta', metavar='Delta',dest='Delta', type=float, default=1.0,
                        help='anisotoropy for SzSz interaction')
    parser.add_argument('-m', metavar='m',dest='m', type=int, default=3,
                        help='Spin size m=2S +1')
    parser.add_argument('-hx', metavar='hx',dest='hx', type=float, default=0.0,
                        help='extarnal magnetix field')
    parser.add_argument('-D', metavar='D',dest='D', type=float, default=0.0,
                        help='single ion anisotropy Sz^2')
    parser.add_argument('-e_num', metavar='e_num',dest='e_num', type=int, default=5,
                        help='number of calculating energies')
    return parser.parse_args()



if __name__ == "__main__":
    ## read params from command line
    args = parse_args()

    eig_val,eig_vec = Calc_GS(args.m,args.Delta,args.hx,args.D,args.N,args.e_num)
    N = args.N
    print "S=1 N-site open Heisenberg chain"
    print "N=",N
    print "Ground state energy per bond=", eig_val[0]/(N-1)
    for i in range(1,args.e_num):
        print "Excited states=",i, eig_val[i]/(N-1)
        
    
