# Sample code for exercise 2-2
# 2017 Augst Tsuyoshi Okubo

import numpy as np
import scipy.linalg as linalg
import ED
import TEBD
from matplotlib import pyplot

N=10           ## Chain length 
m = 3         ## m = 2S + 1, e.g. m=3 for S=1 
Delta = 1.0   ## Delta for XXZ
hx = 0.0      ## external field along x direction
D = 0.0       ## single ion anisotropy

chi_max = 10      ## maxmum bond dimension at truncation


eig_val,eig_vec = ED.Calc_GS(m,Delta,hx,D,N,k=1)

print "S=1 N-site open Heisenberg chain"
print "N=",N
print "Ground state energy per bond=", eig_val[0]/(N-1)


## Make exact MPS (from "left")
Tn = []
lam = [np.ones((1,))]
lam_inv = 1.0/lam[0]
R_mat = eig_vec[:,0].reshape(m,m**(N-1))

chi_l=1
for i in range(N-1):
    U,s,VT = linalg.svd(R_mat,full_matrices=False)
    chi_r = s.size

    Tn.append(np.tensordot(np.diag(lam_inv),U.reshape(chi_l,m,chi_r),(1,0)).transpose(1,0,2))
    lam.append(s)
    lam_inv = 1.0/s
    R_mat = np.dot(np.diag(s),VT).reshape(chi_r*m,m**(N-i-2))
    chi_l = chi_r
Tn.append(VT.reshape(m,m,1).transpose(1,0,2))
lam.append(np.ones((1,)))

## Truncation 
for i in range(N-1):
    chi = min(chi_max,lam[i+1].shape[0])
    lam[i+1]=lam[i+1][:chi]
    Tn[i]=Tn[i][:,:,:chi]
    Tn[i+1]=Tn[i+1][:,:chi,:]


## Calculate Energy
Env_left=[]
Env_right=[]
for i in range(N):
    Env_left.append(np.identity((lam[i].shape[0])))
    Env_right.append(np.dot(np.dot(np.diag(lam[i+1]),np.identity((lam[i+1].shape[0]))),np.diag(lam[i+1])))

print "Truncation: chi_max =",chi_max
print "Energy of MPS with truncation",TEBD.Calc_Energy(Env_left,Env_right,Tn,lam,Delta,hx,D)


    
