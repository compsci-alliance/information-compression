# Image SVD
# 2017 November Tsuyoshi Okubo
# 2018 November Tsuyoshi Okubo

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy
from matplotlib import pyplot
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description='Low rank approximation of an image')
    parser.add_argument('-c', '--chi',metavar='chi',dest='chi', type=int, default=10,
                        help='rank of the approximated matrix. (default: chi = 10)')
    parser.add_argument('-f', '--file',metavar='filename',dest='filename', default="sample.jpg",
                        help='filename of the image. (default: sample.jpg)')

    return parser.parse_args()

def main():
    args = parse_args()
    chi = args.chi
    filename = args.filename

    
    img = Image.open(filename) ## load image
    img_gray = img.convert("L") ## convert to grayscale
    #img_gray.show() ## show image
    img_gray.save("./gray.png") ## save grayscale image
    #img_gray.save("./gray.jpg") ## save grayscale image in jpg

    array = np.array(img_gray,dtype=float) ## convert to ndarray
    print("Input file: " + filename) ## print array shape
    print("Array shape: " +repr(array.shape)) ## print array shape
    if chi >  np.min(array.shape):
        raise ValueError("chi must be smaller than the matrix size.")
    
    u,s,vt = np.linalg.svd(array,full_matrices=False) ## svd 

    ## low-rank approximation
    u_ = u[:,:chi]
    vt_ = vt[:chi,:]
    s_ = s[:chi]

    array_truncated = np.dot(np.dot(u_,np.diag(s_)),vt_) ## make truncated array
    normalized_distance = np.sqrt(np.sum((array-array_truncated)**2))/np.sqrt(np.sum(array**2))
    print("Low rank approximation with chi=" +repr(chi))
    print("Normalized distance:" +repr(normalized_distance)) ## print normalized distance
    #print("Truncation error:" +repr(np.sqrt(np.sum(s[chi:]**2)/np.sum(s**2)))) ## print Truncation error

    img_gray_truncated = Image.fromarray(np.uint8(np.clip(array_truncated,0,255)))
    img_gray_truncated.save("./gray_truncated.png") ## save compressed image
    img_gray_truncated.show(title="Truncated") ## show image in external window
    
    ## normalization of singular values
    s = s/np.sqrt(np.sum(s**2))

    output_sv = len(s) ## number of singular values to output
    pyplot.title("Singular Value Spectrum of the image")
    pyplot.plot(np.arange(output_sv),s[:output_sv],"o")
    pyplot.xlabel("Index")
    pyplot.ylabel("sigma")
    pyplot.yscale("log")
    pyplot.show()


if __name__ == "__main__":
    main()
    
