
# coding: utf-8

# In[1]:

# Image compression by SVD
# for color image
# 2017, 2018 Tsuyoshi Okubo


# By using the low rank approximation through SVD, perform data compression of a color image. 
# 
# You can change sample image by modifying file open "sample_color.jpg".
# 
# Also, you can set the rank of approximation by varying "chi".
# 
# Let's see, how the image changes when you change the rank.

# In[2]:

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy


# In[3]:

img = Image.open("./sample_color.jpg") ## load image
#img = Image.open("./sample_color2.jpg") ## load image
img.show(title="Original") ## show image
img.save("./img_original.png") ## save image


# In[4]:

array = np.array(img) ## convert to ndarray
print("Array shape:" + repr(array.shape)) ## output array shape


# In[5]:

array_truncated = np.zeros(array.shape)


# In[6]:

## svd for each color

chi = 50
print("SVD: chi=" +repr(chi))
for i in range(3):
    u,s,vt = np.linalg.svd(array[:,:,i],full_matrices=False) ## svd 
    
    #truncation
    u = u[:,:chi]
    vt = vt[:chi,:]
    s = s[:chi]

    array_truncated[:,:,i] = np.dot(np.dot(u,np.diag(s)),vt) ## make truncated array


# In[7]:

img_truncated = Image.fromarray(np.uint8(np.clip(array_truncated,0,255))) ## convert to RGB
img_truncated.show(title="Truncated") ## show image
img_truncated.save("./img_truncated.png") ## save compressed image
#img_truncated.save("./img_truncated.jpg") ## save compressed image in jpg


# In[ ]:



