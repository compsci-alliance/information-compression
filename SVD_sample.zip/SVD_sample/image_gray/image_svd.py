
# coding: utf-8

# In[1]:

# Image compression by SVD
# 2017,2018 Tsuyoshi Okubo


# By using the low rank approximation through SVD, perform data compression of a gray scale image. 
# 
# You can change sample image by modifying file open "sample.jpg".
# 
# Also, you can set the rank of approximation by varying "chi".
# 
# Let's see, how the image changes when you change the rank.

# In[2]:

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy


# In[3]:

img = Image.open("./sample.jpg") ## load image
img_gray = img.convert("L") ## convert to grayscale
img_gray.show(title="Original") ## show image in external window
img_gray.save("./gray.png") ## save grayscale image
#img_gray.save("./gray.jpg") ## save grayscale image in jpg


# In[4]:

array = np.array(img_gray) ## convert to ndarray
print("Array shape:" +repr(array.shape)) ## print array shape


# In[5]:

u,s,vt = np.linalg.svd(array,full_matrices=False) ## svd 


# In[6]:

#truncation
chi = 100
print("SVD: chi=" +repr(chi))
u = u[:,:chi]
vt = vt[:chi,:]
s = s[:chi]


# In[7]:

array_truncated = np.dot(np.dot(u,np.diag(s)),vt) ## make truncated array


# In[8]:

img_gray_truncated = Image.fromarray(np.uint8(np.clip(array_truncated,0,255))) ## convert to grayscale image


# In[9]:

img_gray_truncated.show(title="Truncated") ## show image in external window
img_gray_truncated.save("./gray_truncated.png") ## save compressed image
#img_gray_truncated.save("./gray_truncated.jpg") ## save compressed image in jpg


# In[ ]:




# In[ ]:



