# coding: utf-8
# Image compression for multi images by HOSVD 
# 2017,2018 Tsuyoshi Okubo
# 2019, October midified by TO

# By using the low rank approximation through HOSVD, perform data compression of multiple gray scale images. 
# 
# You can change sample images by modifying file opens.
# We assume filenames are "1.jpg", "2.jpg", ...
# Please set proper value for "n_image" depending the number of images.
# 
# Also, you can set the rank of approximation by varying "chi" and "chi_p", which correspond the rank for images and the rank for # of images.
# 
# The output images (after data compression) are saved into "outputs/" directory.
# 
# Let's see, how the images change when you change the ranks.

## import libraries
from PIL import Image ## Python Imaging Library
import numpy as np ## numpy
from matplotlib import pyplot
import argparse

def parse_args():
    parser = argparse.ArgumentParser(description='Low rank approximation of an image')

    parser.add_argument('-n', '--n_image',metavar='n_image',dest='n_image', type=int, default=10,
                        help='number of images. (default: n_image = 10)')

    parser.add_argument('-c', '--chi',metavar='chi',dest='chi', type=int, default=30,
                        help='rank of the images. (default: chi = 30)')
    parser.add_argument('-cp', '--chi_p ',metavar='chi_p',dest='chi_p', type=int, default=9,
                        help='rank of the number of images. (default: chi_p = 9)')
    parser.add_argument('-d', '--dirname',metavar='dirname',dest='dirname', default="samples",
                        help='diractory name where image files exist. (default: samples)')

    return parser.parse_args()

def main():
    args = parse_args()
    chi = args.chi
    chi_p = args.chi_p
    dirname = args.dirname
    n_image = args.n_image


    array=[]
    for i in range(1,n_image+1):
        img = Image.open(dirname+"/"+repr(i)+".bmp") ## load bmp image    
        array.append(np.array(img,dtype=float)) ## put into ndarray
        ## array.append(np.array(img.convert("L"),dtype=float)) ## put into ndarray (for color images)

    array=np.array(array).transpose(1,2,0) 
    print("Input directory: " + dirname) 
    if chi >  np.min(array.shape[:2]):
        raise ValueError("chi must be smaller than the matrix size.")
    if chi_p >  array.shape[2]:
        raise ValueError("chi_p must be smaller than the matrix size.")
    print("Array shape:" +repr(array.shape)) ## print array shape

    array_truncated = np.zeros(array.shape)

    ## row
    matrix = np.reshape(array,(array.shape[0],array.shape[1]*array.shape[2]))
    u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 

    #truncation
    u1 = u[:,:chi]

    ## column
    matrix = np.reshape(np.transpose(array,(1,0,2)),(array.shape[1],array.shape[0]*array.shape[2]))
    u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 

    #truncation
    u2 = u[:,:chi]

    ## layer
    matrix = np.reshape(np.transpose(array,(2,0,1)),(array.shape[2],array.shape[0]*array.shape[1]))
    u,s,vt = np.linalg.svd(matrix[:,:],full_matrices=False) ## svd 

    #truncation
    u3 = u[:,:chi_p]


    ## make projectors
    p1 = np.dot(u1,(u1.conj()).T)
    p2 = np.dot(u2,(u2.conj()).T)
    p3 = np.dot(u3,(u3.conj()).T)


    # In[8]:


    ## make truncated array
    array_truncated = np.tensordot(np.tensordot(np.tensordot(array,p1,axes=(0,1)),p2,axes=(0,1)),p3,axes=(0,1))
    normalized_distance = np.sqrt(np.sum((array-array_truncated)**2))/np.sqrt(np.sum(array**2))
    print("Low rank approximation by HOSVD with chi= " +repr(chi)+ ", chi_p= "+repr(chi_p))
    print("Normalized distance:" +repr(normalized_distance)) ## print normalized distance

    # In[10]:


    for i in range(1,n_image):    
        img_truncated = Image.fromarray(np.uint8(np.clip(array_truncated[:,:,i-1],0,255))) ## convert to each image
        img_truncated.save("./outputs/"+repr(i)+".bmp") ## save compressed image
        ##img_truncated.save("./outputs/"+repr(i)+".png") ## save compressed image
if __name__ == "__main__":
    main()

